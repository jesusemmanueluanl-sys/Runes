package com.example.rvh;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;

import java.util.*;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class RunnersVsHunters implements ModInitializer {

    private static final int MAX_LIVES = 2;

    record EffectOption(StatusEffect effect, int maxAmplifier) {}
    record DeathSpot(RegistryKey<World> dim, Vec3d pos, float yaw, float pitch) {}

    private static final List<EffectOption> EFFECTS = List.of(
            new EffectOption(StatusEffects.SPEED, 2),
            new EffectOption(StatusEffects.HASTE, 2),
            new EffectOption(StatusEffects.STRENGTH, 1),
            new EffectOption(StatusEffects.JUMP_BOOST, 2),
            new EffectOption(StatusEffects.REGENERATION, 1),
            new EffectOption(StatusEffects.RESISTANCE, 2),
            new EffectOption(StatusEffects.HEALTH_BOOST, 2),
            new EffectOption(StatusEffects.FIRE_RESISTANCE, 0),
            new EffectOption(StatusEffects.WATER_BREATHING, 0),
            new EffectOption(StatusEffects.NIGHT_VISION, 0),
            new EffectOption(StatusEffects.SLOW_FALLING, 0),
            new EffectOption(StatusEffects.LUCK, 2)
    );

    private final Set<UUID> hunters = new HashSet<>();
    private final Set<UUID> runners = new HashSet<>();
    private final Map<UUID, Integer> lives = new HashMap<>();
    private final Map<UUID, DeathSpot> deathSpots = new HashMap<>();
    private final Map<UUID, StatusEffectInstance> assigned = new HashMap<>();
    private final Random rnd = new Random();
    private boolean running = false;

    @Override
    public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(this::enableKeepInventory);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) ->
            dispatcher.register(literal("rvh").requires(s -> s.hasPermissionLevel(2))
                .then(literal("hunter").then(argument("jugador", EntityArgumentType.player()).executes(ctx -> {
                    ServerPlayerEntity p = EntityArgumentType.getPlayer(ctx, "jugador");
                    runners.remove(p.getUuid());
                    hunters.add(p.getUuid());
                    ctx.getSource().sendFeedback(() -> Text.literal(p.getName().getString() + " ahora es HUNTER"), true);
                    return 1;
                })))
                .then(literal("runner").then(argument("jugador", EntityArgumentType.player()).executes(ctx -> {
                    ServerPlayerEntity p = EntityArgumentType.getPlayer(ctx, "jugador");
                    hunters.remove(p.getUuid());
                    runners.add(p.getUuid());
                    ctx.getSource().sendFeedback(() -> Text.literal(p.getName().getString() + " ahora es RUNNER"), true);
                    return 1;
                })))
                .then(literal("random").executes(ctx -> {
                    List<ServerPlayerEntity> list = new ArrayList<>(ctx.getSource().getServer().getPlayerManager().getPlayerList());
                    if (list.size() < 2) {
                        ctx.getSource().sendError(Text.literal("Se necesitan al menos 2 jugadores."));
                        return 0;
                    }
                    hunters.clear();
                    runners.clear();
                    ServerPlayerEntity runner = list.get(rnd.nextInt(list.size()));
                    for (ServerPlayerEntity p : list) {
                        if (p == runner) runners.add(p.getUuid());
                        else hunters.add(p.getUuid());
                    }
                    ctx.getSource().getServer().getPlayerManager().broadcast(
                            Text.literal("Runner: " + runner.getName().getString() + " | Los demás son hunters")
                                    .formatted(Formatting.GOLD), false);
                    return 1;
                }))
                .then(literal("start").executes(ctx -> {
                    if (runners.isEmpty() || hunters.isEmpty()) {
                        ctx.getSource().sendError(Text.literal("Define al menos un runner y un hunter."));
                        return 0;
                    }
                    startGame(ctx.getSource().getServer());
                    return 1;
                }))
                .then(literal("stop").executes(ctx -> {
                    running = false;
                    ctx.getSource().sendFeedback(() -> Text.literal("Partida detenida."), true);
                    return 1;
                }))
            ));

        ServerLivingEntityEvents.AFTER_DEATH.register(this::onDeath);

        ServerPlayerEvents.AFTER_RESPAWN.register((oldP, newP, alive) -> {
            if (!running) return;
            UUID id = newP.getUuid();
            if (runners.contains(id) && deathSpots.containsKey(id)) {
                DeathSpot s = deathSpots.remove(id);
                ServerWorld w = newP.getServer().getWorld(s.dim());
                if (w != null) newP.teleport(w, s.pos().x, s.pos().y, s.pos().z, s.yaw(), s.pitch());
            }
            StatusEffectInstance e = assigned.get(id);
            if (e != null) newP.addStatusEffect(new StatusEffectInstance(e));
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!running || server.getTicks() % 10 != 0) return;
            for (UUID hid : hunters) {
                ServerPlayerEntity hunter = server.getPlayerManager().getPlayer(hid);
                if (hunter == null || !hunter.isAlive()) continue;
                ServerPlayerEntity target = nearestRunner(server, hunter);
                if (target == null) continue;
                for (int i = 0; i < hunter.getInventory().size(); i++) {
                    ItemStack st = hunter.getInventory().getStack(i);
                    if (st.isOf(Items.COMPASS)) pointCompass(st, target);
                }
            }
        });
    }

    private void enableKeepInventory(MinecraftServer server) {
        server.getGameRules().get(GameRules.KEEP_INVENTORY).set(true, server);
    }

    private void startGame(MinecraftServer server) {
        enableKeepInventory(server);
        running = true;
        lives.clear();
        deathSpots.clear();
        assigned.clear();

        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            UUID id = p.getUuid();
            if (!hunters.contains(id) && !runners.contains(id)) continue;

            p.clearStatusEffects();
            EffectOption opt = EFFECTS.get(rnd.nextInt(EFFECTS.size()));
            int amp = rnd.nextInt(opt.maxAmplifier() + 1);
            StatusEffectInstance inst = new StatusEffectInstance(
                    opt.effect(), 20_000_000, amp, false, true);
            assigned.put(id, inst);
            p.addStatusEffect(new StatusEffectInstance(inst));
            p.sendMessage(Text.literal("Tu efecto: ").append(opt.effect().getName())
                    .append(" " + (amp + 1)).formatted(Formatting.AQUA), false);

            if (runners.contains(id)) {
                lives.put(id, MAX_LIVES);
                p.sendMessage(Text.literal("Eres RUNNER. Vidas: " + MAX_LIVES).formatted(Formatting.GREEN), false);
            } else {
                p.giveItemStack(new ItemStack(Items.COMPASS));
                p.sendMessage(Text.literal("Eres HUNTER. Atrapa al runner.").formatted(Formatting.RED), false);
            }
        }
        server.getPlayerManager().broadcast(Text.literal("¡Comienza la partida!").formatted(Formatting.GOLD), false);
    }

    private void onDeath(LivingEntity entity, DamageSource source) {
        if (!running || !(entity instanceof ServerPlayerEntity victim)) return;
        UUID vid = victim.getUuid();
        if (!runners.contains(vid)) return;

        MinecraftServer server = victim.getServer();

        // Lo mató un hunter: GAME OVER directo, sin importar las vidas
        if (source.getAttacker() instanceof ServerPlayerEntity killer && hunters.contains(killer.getUuid())) {
            running = false;
            deathSpots.remove(vid);

            killer.networkHandler.sendPacket(new TitleS2CPacket(
                    Text.literal("¡Ganaste!").formatted(Formatting.GOLD, Formatting.BOLD)));
            killer.sendMessage(Text.literal("¡Ganaste! Mataste al runner.")
                    .formatted(Formatting.GOLD), false);
            victim.sendMessage(Text.literal("Un hunter te mató. GAME OVER.")
                    .formatted(Formatting.RED, Formatting.BOLD), false);
            server.getPlayerManager().broadcast(
                    Text.literal("¡Los HUNTERS ganan la partida!").formatted(Formatting.GOLD, Formatting.BOLD), false);
            return;
        }

        // Murió de otra forma: pierde una vida, sin mensaje de "ganaste"
        int left = lives.merge(vid, -1, Integer::sum);

        if (left <= 0) {
            running = false;
            deathSpots.remove(vid);
            server.getPlayerManager().broadcast(
                    Text.literal("El runner se quedó sin vidas. Partida terminada.")
                            .formatted(Formatting.GRAY), false);
            return;
        }

        deathSpots.put(vid, new DeathSpot(victim.getWorld().getRegistryKey(),
                victim.getPos(), victim.getYaw(), victim.getPitch()));
        victim.sendMessage(Text.literal("Moriste. Vidas restantes: " + left)
                .formatted(Formatting.YELLOW), false);
    }

    private ServerPlayerEntity nearestRunner(MinecraftServer server, ServerPlayerEntity hunter) {
        ServerPlayerEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (UUID rid : runners) {
            ServerPlayerEntity r = server.getPlayerManager().getPlayer(rid);
            if (r == null || !r.isAlive() || r.getWorld() != hunter.getWorld()) continue;
            double d = r.squaredDistanceTo(hunter);
            if (d < bestDist) { bestDist = d; best = r; }
        }
        return best;
    }

    private void pointCompass(ItemStack compass, ServerPlayerEntity target) {
        var nbt = compass.getOrCreateNbt();
        nbt.put("LodestonePos", NbtHelper.fromBlockPos(target.getBlockPos()));
        nbt.putString("LodestoneDimension", target.getWorld().getRegistryKey().getValue().toString());
        nbt.putBoolean("LodestoneTracked", false);
    }
}
