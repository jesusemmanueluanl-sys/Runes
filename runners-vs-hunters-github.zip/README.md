# Runners vs Hunters (Fabric 1.20.1)

Mod de Minecraft Java 1.20.1 (Fabric) con runner(s) contra hunters.

## Reglas
- El runner tiene **2 vidas**.
- Si muere por un **hunter**: game over inmediato y al hunter le sale "¡Ganaste!".
- Si muere de **otra forma**: pierde 1 vida, no hay mensaje y reaparece donde murió.
- Sin vidas: la partida termina.
- Todos reciben un efecto bueno aleatorio (casi infinito) con nivel aleatorio.
- Keep inventory activo. Los hunters tienen una brújula que apunta al runner.

## Comandos (OP)
| Comando | Acción |
|---|---|
| `/rvh hunter <jugador>` | Asigna hunter |
| `/rvh runner <jugador>` | Asigna runner |
| `/rvh random` | Runner al azar, el resto hunters |
| `/rvh start` / `/rvh stop` | Inicia / detiene |

## Descargar el .jar
Pestaña **Actions** > última ejecución > **Artifacts** > `runners-vs-hunters`.
Para una descarga fija: crea una etiqueta (`git tag v1.0.0 && git push --tags`) y el .jar aparece en **Releases**.

Instalación: ponlo en `mods/` junto con **Fabric API 0.92.2+1.20.1**.
